export class Temp
{
public Id:Number;
public Name:String;
}